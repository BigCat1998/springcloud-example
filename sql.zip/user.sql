/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50562
Source Host           : localhost:3306
Source Database       : user

Target Server Type    : MYSQL
Target Server Version : 50562
File Encoding         : 65001

Date: 2020-03-24 16:57:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_message
-- ----------------------------
DROP TABLE IF EXISTS `tb_message`;
CREATE TABLE `tb_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `is_receive` int(11) DEFAULT NULL,
  `message_data` varchar(255) DEFAULT NULL,
  `receive_id` int(11) DEFAULT NULL,
  `send_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_message
-- ----------------------------
INSERT INTO `tb_message` VALUES ('8', '2020-03-24 00:00:00', '0', 'home2 你好呀', '2', '1');
INSERT INTO `tb_message` VALUES ('9', '2020-03-24 00:00:00', '0', 'home1 你也好呀', '1', '2');
INSERT INTO `tb_message` VALUES ('10', '2020-03-24 00:00:00', '0', 'home2 你好呀', '2', '1');
INSERT INTO `tb_message` VALUES ('11', '2020-03-24 00:00:00', '0', 'home1 你也好呀', '1', '2');

-- ----------------------------
-- Table structure for tb_message_list
-- ----------------------------
DROP TABLE IF EXISTS `tb_message_list`;
CREATE TABLE `tb_message_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receive_id` int(11) DEFAULT NULL,
  `send_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_message_list
-- ----------------------------
INSERT INTO `tb_message_list` VALUES ('1', '2', '1');
INSERT INTO `tb_message_list` VALUES ('2', '1', '2');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `user_name` varchar(255) NOT NULL COMMENT '用户名称',
  `user_password` varchar(26) NOT NULL COMMENT '用户密码',
  `user_balance` double NOT NULL COMMENT '余额',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('1', 'wangwu', '123456', '10000');
INSERT INTO `tb_user` VALUES ('2', 'zhangsan', '123456', '9749.800000000001');
