/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50562
Source Host           : localhost:3306
Source Database       : commodity

Target Server Type    : MYSQL
Target Server Version : 50562
File Encoding         : 65001

Date: 2020-03-24 16:57:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_commodity
-- ----------------------------
DROP TABLE IF EXISTS `tb_commodity`;
CREATE TABLE `tb_commodity` (
  `commodity_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `commodity_name` varchar(255) NOT NULL COMMENT '商品名称',
  `commodity_price` double NOT NULL COMMENT '商品价格',
  `commodity_stock` int(11) NOT NULL COMMENT '库存',
  PRIMARY KEY (`commodity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_commodity
-- ----------------------------
INSERT INTO `tb_commodity` VALUES ('1', '苹果', '13.9', '982');
INSERT INTO `tb_commodity` VALUES ('2', '梨', '30.2', '500');
INSERT INTO `tb_commodity` VALUES ('6', '橘子', '5.8', '4000');
